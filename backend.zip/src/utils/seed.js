// Jalankan: npm run seed
// Membuat 1 akun admin dan 1 akun customer default untuk testing.
const bcrypt = require('bcryptjs');
const { pool } = require('../config/db');

async function seed() {
  const password = 'password123';
  const hash = await bcrypt.hash(password, 10);

  const users = [
    ['Admin User', 'admin@example.com', hash, 'admin'],
    ['Customer Demo', 'customer@example.com', hash, 'customer'],
  ];

  for (const [name, email, password_hash, role] of users) {
    const [existing] = await pool.query('SELECT id FROM users WHERE email = ?', [email]);
    if (existing.length > 0) {
      console.log(`⏭️  Skip, sudah ada: ${email}`);
      continue;
    }
    await pool.query(
      'INSERT INTO users (name, email, password_hash, role) VALUES (?, ?, ?, ?)',
      [name, email, password_hash, role]
    );
    console.log(`✅ Dibuat: ${email} (role: ${role}) — password: ${password}`);
  }

  process.exit(0);
}

seed().catch((err) => {
  console.error('Gagal seeding:', err);
  process.exit(1);
});
