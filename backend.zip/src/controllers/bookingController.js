const { pool } = require('../config/db');

const BOOKING_SELECT = `
  SELECT b.*, r.name AS room_name, r.price_per_day, u.name AS user_name, u.email AS user_email
  FROM bookings b
  JOIN rooms r ON r.id = b.room_id
  JOIN users u ON u.id = b.user_id
`;

// GET /api/bookings
// Customer: hanya lihat booking miliknya. Admin: lihat semua.
async function getBookings(req, res, next) {
  try {
    let rows;
    if (req.user.role === 'admin') {
      [rows] = await pool.query(`${BOOKING_SELECT} ORDER BY b.start_time DESC`);
    } else {
      [rows] = await pool.query(
        `${BOOKING_SELECT} WHERE b.user_id = ? ORDER BY b.start_time DESC`,
        [req.user.id]
      );
    }
    res.json({ bookings: rows });
  } catch (err) {
    next(err);
  }
}

// GET /api/bookings/:id
async function getBookingById(req, res, next) {
  try {
    const { id } = req.params;
    const [rows] = await pool.query(`${BOOKING_SELECT} WHERE b.id = ?`, [id]);
    if (rows.length === 0) {
      return res.status(404).json({ message: 'Booking tidak ditemukan.' });
    }
    const booking = rows[0];
    if (req.user.role !== 'admin' && booking.user_id !== req.user.id) {
      return res.status(403).json({ message: 'Anda tidak berhak melihat booking ini.' });
    }
    res.json({ booking });
  } catch (err) {
    next(err);
  }
}

// POST /api/bookings
// start_time/end_time sekarang merepresentasikan tanggal check-in & check-out
// (booking dihitung per hari, bukan per jam lagi).
async function createBooking(req, res, next) {
  try {
    const { room_id, start_time, end_time, notes } = req.body;

    if (!room_id || !start_time || !end_time) {
      return res.status(400).json({ message: 'room_id, tanggal check-in, dan tanggal check-out wajib diisi.' });
    }

    const start = new Date(start_time);
    const end = new Date(end_time);

    if (isNaN(start.getTime()) || isNaN(end.getTime())) {
      return res.status(400).json({ message: 'Format tanggal tidak valid.' });
    }
    if (end <= start) {
      return res.status(400).json({ message: 'Tanggal check-out harus setelah tanggal check-in.' });
    }

    // Bandingkan hanya tanggalnya (bukan jam) supaya booking untuk "hari ini" tetap valid.
    const todayDateOnly = new Date();
    todayDateOnly.setHours(0, 0, 0, 0);
    if (start < todayDateOnly) {
      return res.status(400).json({ message: 'Tidak bisa booking untuk tanggal yang sudah lewat.' });
    }

    const [roomRows] = await pool.query('SELECT * FROM rooms WHERE id = ? AND is_active = 1', [room_id]);
    if (roomRows.length === 0) {
      return res.status(404).json({ message: 'Room tidak ditemukan atau tidak aktif.' });
    }
    const room = roomRows[0];

    // Cek konflik jadwal: booking lain di room yang sama, status bukan cancelled,
    // dan rentang tanggalnya beririsan dengan rentang yang diminta.
    const [conflicts] = await pool.query(
      `SELECT id FROM bookings
       WHERE room_id = ?
         AND status != 'cancelled'
         AND start_time < ?
         AND end_time > ?`,
      [room_id, end_time, start_time]
    );

    if (conflicts.length > 0) {
      return res.status(409).json({ message: 'Room sudah dibooking pada rentang tanggal tersebut.' });
    }

    const days = Math.round((end - start) / (1000 * 60 * 60 * 24));
    const total_price = Math.round(days * Number(room.price_per_day) * 100) / 100;

    const [result] = await pool.query(
      `INSERT INTO bookings (user_id, room_id, start_time, end_time, status, notes, total_price)
       VALUES (?, ?, ?, ?, 'pending', ?, ?)`,
      [req.user.id, room_id, start_time, end_time, notes || null, total_price]
    );

    const [rows] = await pool.query(`${BOOKING_SELECT} WHERE b.id = ?`, [result.insertId]);
    res.status(201).json({ booking: rows[0] });
  } catch (err) {
    next(err);
  }
}

// PUT /api/bookings/:id/status (admin) - confirm / cancel
async function updateBookingStatus(req, res, next) {
  try {
    const { id } = req.params;
    const { status } = req.body;

    if (!['pending', 'confirmed', 'cancelled'].includes(status)) {
      return res.status(400).json({ message: 'Status tidak valid.' });
    }

    const [existing] = await pool.query('SELECT * FROM bookings WHERE id = ?', [id]);
    if (existing.length === 0) {
      return res.status(404).json({ message: 'Booking tidak ditemukan.' });
    }

    await pool.query('UPDATE bookings SET status = ? WHERE id = ?', [status, id]);
    const [rows] = await pool.query(`${BOOKING_SELECT} WHERE b.id = ?`, [id]);
    res.json({ booking: rows[0] });
  } catch (err) {
    next(err);
  }
}

// DELETE /api/bookings/:id - customer membatalkan booking miliknya sendiri
async function cancelBooking(req, res, next) {
  try {
    const { id } = req.params;
    const [existing] = await pool.query('SELECT * FROM bookings WHERE id = ?', [id]);
    if (existing.length === 0) {
      return res.status(404).json({ message: 'Booking tidak ditemukan.' });
    }
    const booking = existing[0];

    if (req.user.role !== 'admin' && booking.user_id !== req.user.id) {
      return res.status(403).json({ message: 'Anda tidak berhak membatalkan booking ini.' });
    }

    await pool.query("UPDATE bookings SET status = 'cancelled' WHERE id = ?", [id]);
    res.json({ message: 'Booking berhasil dibatalkan.' });
  } catch (err) {
    next(err);
  }
}

module.exports = {
  getBookings,
  getBookingById,
  createBooking,
  updateBookingStatus,
  cancelBooking,
};
