const { pool } = require('../config/db');
const fs = require('fs');
const path = require('path');

// Kategori yang didukung. Dipakai untuk validasi ringan di createRoom/updateRoom.
const ALLOWED_CATEGORIES = ['Meeting Room', 'Aula Konferensi', 'Coworking Desk', 'Lainnya'];

// Ambil semua room lalu tempelkan array `images` untuk masing-masing (menghindari N+1 query).
async function attachImages(rooms) {
  if (rooms.length === 0) return rooms;
  const ids = rooms.map((r) => r.id);
  const [imageRows] = await pool.query(
    `SELECT * FROM room_images WHERE room_id IN (?) ORDER BY sort_order ASC, id ASC`,
    [ids]
  );
  const byRoom = {};
  for (const img of imageRows) {
    if (!byRoom[img.room_id]) byRoom[img.room_id] = [];
    byRoom[img.room_id].push(img);
  }
  return rooms.map((r) => ({ ...r, images: byRoom[r.id] || [] }));
}

// GET /api/rooms
// Query opsional: ?country=Indonesia&location=Bandung untuk filter pencarian lokasi.
// ?includeInactive=true dipakai halaman admin supaya ruang yang dinonaktifkan tetap tampil di tabel
// (jadi checkbox status bisa dipakai untuk mengaktifkan kembali).
async function getRooms(req, res, next) {
  try {
    const { country, location, includeInactive } = req.query;
    const conditions = [];
    const params = [];

    if (includeInactive !== 'true') {
      conditions.push('is_active = 1');
    }
    if (country) {
      conditions.push('country LIKE ?');
      params.push(`%${country}%`);
    }
    if (location) {
      conditions.push('location LIKE ?');
      params.push(`%${location}%`);
    }

    const where = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';
    const [rows] = await pool.query(
      `SELECT * FROM rooms ${where} ORDER BY name ASC`,
      params
    );
    const rooms = await attachImages(rows);
    res.json({ rooms });
  } catch (err) {
    next(err);
  }
}

// GET /api/rooms/:id
async function getRoomById(req, res, next) {
  try {
    const { id } = req.params;
    const [rows] = await pool.query('SELECT * FROM rooms WHERE id = ?', [id]);
    if (rows.length === 0) {
      return res.status(404).json({ message: 'Room tidak ditemukan.' });
    }
    const [room] = await attachImages(rows);
    res.json({ room });
  } catch (err) {
    next(err);
  }
}

// POST /api/rooms (admin)
async function createRoom(req, res, next) {
  try {
    const { name, description, capacity, price_per_day, image_url, category, location, country, rating } = req.body;
    if (!name || !capacity || price_per_day === undefined) {
      return res.status(400).json({ message: 'name, capacity, dan price_per_day wajib diisi.' });
    }
    if (category && !ALLOWED_CATEGORIES.includes(category)) {
      return res.status(400).json({ message: `category harus salah satu dari: ${ALLOWED_CATEGORIES.join(', ')}` });
    }
    if (rating !== undefined && (rating < 0 || rating > 5)) {
      return res.status(400).json({ message: 'rating harus antara 0 dan 5.' });
    }

    const [result] = await pool.query(
      `INSERT INTO rooms (name, description, capacity, price_per_day, image_url, category, location, country, rating)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        name,
        description || null,
        capacity,
        price_per_day,
        image_url || null,
        category || 'Lainnya',
        location || null,
        country || 'Indonesia',
        rating || 0,
      ]
    );

    const [rows] = await pool.query('SELECT * FROM rooms WHERE id = ?', [result.insertId]);
    const [room] = await attachImages(rows);
    res.status(201).json({ room });
  } catch (err) {
    next(err);
  }
}

// PUT /api/rooms/:id (admin)
async function updateRoom(req, res, next) {
  try {
    const { id } = req.params;
    const { name, description, capacity, price_per_day, image_url, category, location, country, rating, is_active } = req.body;

    const [existing] = await pool.query('SELECT * FROM rooms WHERE id = ?', [id]);
    if (existing.length === 0) {
      return res.status(404).json({ message: 'Room tidak ditemukan.' });
    }
    const current = existing[0];

    if (category && !ALLOWED_CATEGORIES.includes(category)) {
      return res.status(400).json({ message: `category harus salah satu dari: ${ALLOWED_CATEGORIES.join(', ')}` });
    }
    if (rating !== undefined && (rating < 0 || rating > 5)) {
      return res.status(400).json({ message: 'rating harus antara 0 dan 5.' });
    }

    await pool.query(
      `UPDATE rooms SET name = ?, description = ?, capacity = ?, price_per_day = ?, image_url = ?,
       category = ?, location = ?, country = ?, rating = ?, is_active = ?
       WHERE id = ?`,
      [
        name ?? current.name,
        description ?? current.description,
        capacity ?? current.capacity,
        price_per_day ?? current.price_per_day,
        image_url ?? current.image_url,
        category ?? current.category,
        location ?? current.location,
        country ?? current.country,
        rating ?? current.rating,
        is_active ?? current.is_active,
        id,
      ]
    );

    const [rows] = await pool.query('SELECT * FROM rooms WHERE id = ?', [id]);
    const [room] = await attachImages(rows);
    res.json({ room });
  } catch (err) {
    next(err);
  }
}

// DELETE /api/rooms/:id (admin) - soft delete
async function deleteRoom(req, res, next) {
  try {
    const { id } = req.params;
    const [existing] = await pool.query('SELECT id FROM rooms WHERE id = ?', [id]);
    if (existing.length === 0) {
      return res.status(404).json({ message: 'Room tidak ditemukan.' });
    }
    await pool.query('UPDATE rooms SET is_active = 0 WHERE id = ?', [id]);
    res.json({ message: 'Room berhasil dinonaktifkan.' });
  } catch (err) {
    next(err);
  }
}

// POST /api/rooms/:id/images (admin) - upload satu atau beberapa foto sekaligus
// Field form-data: "images" (multiple files)
async function uploadRoomImages(req, res, next) {
  try {
    const { id } = req.params;
    const [existing] = await pool.query('SELECT id FROM rooms WHERE id = ?', [id]);
    if (existing.length === 0) {
      return res.status(404).json({ message: 'Room tidak ditemukan.' });
    }

    const files = req.files || [];
    if (files.length === 0) {
      return res.status(400).json({ message: 'Tidak ada file yang diupload.' });
    }

    const [[{ maxOrder }]] = await pool.query(
      'SELECT COALESCE(MAX(sort_order), -1) AS maxOrder FROM room_images WHERE room_id = ?',
      [id]
    );

    let order = maxOrder + 1;
    const inserted = [];
    for (const file of files) {
      const relativeUrl = `/uploads/rooms/${file.filename}`;
      const [result] = await pool.query(
        'INSERT INTO room_images (room_id, image_url, sort_order) VALUES (?, ?, ?)',
        [id, relativeUrl, order]
      );
      inserted.push({ id: result.insertId, room_id: Number(id), image_url: relativeUrl, sort_order: order });
      order += 1;
    }

    // Kalau room belum punya image_url utama (cover), pakai foto pertama yang baru diupload.
    const [[room]] = await pool.query('SELECT image_url FROM rooms WHERE id = ?', [id]);
    if (!room.image_url) {
      await pool.query('UPDATE rooms SET image_url = ? WHERE id = ?', [inserted[0].image_url, id]);
    }

    res.status(201).json({ images: inserted });
  } catch (err) {
    next(err);
  }
}

// DELETE /api/rooms/:id/images/:imageId (admin)
async function deleteRoomImage(req, res, next) {
  try {
    const { id, imageId } = req.params;
    const [rows] = await pool.query(
      'SELECT * FROM room_images WHERE id = ? AND room_id = ?',
      [imageId, id]
    );
    if (rows.length === 0) {
      return res.status(404).json({ message: 'Foto tidak ditemukan.' });
    }
    const image = rows[0];

    await pool.query('DELETE FROM room_images WHERE id = ?', [imageId]);

    // Hapus file fisiknya juga (best-effort, tidak menggagalkan request kalau gagal).
    const filePath = path.join(__dirname, '..', '..', image.image_url.replace(/^\//, ''));
    fs.unlink(filePath, () => {});

    res.json({ message: 'Foto berhasil dihapus.' });
  } catch (err) {
    next(err);
  }
}

module.exports = {
  getRooms,
  getRoomById,
  createRoom,
  updateRoom,
  deleteRoom,
  uploadRoomImages,
  deleteRoomImage,
  ALLOWED_CATEGORIES,
};
