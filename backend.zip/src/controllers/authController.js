const bcrypt = require('bcryptjs');
const { pool } = require('../config/db');
const { signToken } = require('../utils/jwt');
const { generateOtp, hashOtp, compareOtp, getOtpExpiry } = require('../utils/otp');
const { sendOtpEmail } = require('../utils/mailer');
const { verifyGoogleToken } = require('../config/google');
const { checkEmailDeliverable } = require('../utils/emailCheck');

const MAX_OTP_ATTEMPTS = 5;

// POST /api/auth/check-email
// Body: { email } -> dipakai frontend buat validasi real-time sebelum submit form.
async function checkEmail(req, res, next) {
  try {
    const { email } = req.body;
    if (!email) {
      return res.status(400).json({ valid: false, reason: 'empty' });
    }

    const result = await checkEmailDeliverable(email);
    if (!result.valid) {
      return res.json(result); // { valid: false, reason }
    }

    const [existing] = await pool.query(
      'SELECT id, email_verified FROM users WHERE email = ?',
      [email]
    );
    if (existing.length > 0 && existing[0].email_verified) {
      return res.json({ valid: true, alreadyRegistered: true });
    }

    res.json({ valid: true, alreadyRegistered: false });
  } catch (err) {
    next(err);
  }
}

// POST /api/auth/register
// Daftar manual: akun dibuat tapi email_verified = 0, lalu kode OTP dikirim ke email.
// User baru bisa login setelah verifikasi OTP berhasil.
async function register(req, res, next) {
  try {
    const { name, email, password } = req.body;

    if (!name || !email || !password) {
      return res.status(400).json({ message: 'Nama, email, dan password wajib diisi.' });
    }
    if (password.length < 6) {
      return res.status(400).json({ message: 'Password minimal 6 karakter.' });
    }

    const emailCheck = await checkEmailDeliverable(email);
    if (!emailCheck.valid) {
      const messages = {
        format: 'Format email tidak valid.',
        disposable: 'Email sementara/sekali-pakai tidak diperbolehkan. Gunakan email aktif kamu.',
        no_mx: 'Domain email ini sepertinya tidak valid atau tidak bisa menerima email. Cek kembali penulisannya.',
      };
      return res.status(400).json({ message: messages[emailCheck.reason] || 'Email tidak valid.' });
    }

    const [existing] = await pool.query('SELECT id, email_verified, provider FROM users WHERE email = ?', [email]);

    if (existing.length > 0) {
      const existingUser = existing[0];
      // Kalau sudah pernah daftar tapi belum verifikasi, kirim ulang OTP saja
      // daripada menolak (biar tidak bikin user stuck kalau OTP sebelumnya hilang/expired).
      if (existingUser.provider === 'local' && !existingUser.email_verified) {
        const otp = generateOtp();
        const otpHash = await hashOtp(otp);
        await pool.query(
          'UPDATE users SET otp_code = ?, otp_expires_at = ?, otp_attempts = 0 WHERE id = ?',
          [otpHash, getOtpExpiry(), existingUser.id]
        );
        await sendOtpEmail(email, name, otp);
        return res.status(200).json({
          message: 'Email ini sudah terdaftar tapi belum diverifikasi. Kode OTP baru sudah dikirim.',
          email,
          needsVerification: true,
        });
      }
      return res.status(409).json({ message: 'Email sudah terdaftar.' });
    }

    const password_hash = await bcrypt.hash(password, 10);
    const [result] = await pool.query(
      'INSERT INTO users (name, email, password_hash, role, provider, email_verified) VALUES (?, ?, ?, ?, ?, ?)',
      [name, email, password_hash, 'customer', 'local', 0]
    );

    const otp = generateOtp();
    const otpHash = await hashOtp(otp);
    await pool.query(
      'UPDATE users SET otp_code = ?, otp_expires_at = ? WHERE id = ?',
      [otpHash, getOtpExpiry(), result.insertId]
    );

    try {
      await sendOtpEmail(email, name, otp);
    } catch (mailErr) {
      console.error('Gagal mengirim email OTP:', mailErr.message);
      return res.status(502).json({
        message: 'Akun dibuat, tapi gagal mengirim email verifikasi. Coba kirim ulang OTP dari halaman verifikasi.',
        email,
        needsVerification: true,
      });
    }

    res.status(201).json({
      message: 'Pendaftaran berhasil. Kode OTP telah dikirim ke email kamu.',
      email,
      needsVerification: true,
    });
  } catch (err) {
    next(err);
  }
}

// POST /api/auth/verify-otp
// Body: { email, otp }
async function verifyOtp(req, res, next) {
  try {
    const { email, otp } = req.body;
    if (!email || !otp) {
      return res.status(400).json({ message: 'Email dan kode OTP wajib diisi.' });
    }

    const [rows] = await pool.query('SELECT * FROM users WHERE email = ?', [email]);
    if (rows.length === 0) {
      return res.status(404).json({ message: 'Akun tidak ditemukan.' });
    }

    const userRow = rows[0];

    if (userRow.email_verified) {
      return res.status(400).json({ message: 'Email ini sudah terverifikasi. Silakan login.' });
    }

    if (!userRow.otp_code || !userRow.otp_expires_at) {
      return res.status(400).json({ message: 'Tidak ada kode OTP aktif. Silakan minta kode baru.' });
    }

    if (userRow.otp_attempts >= MAX_OTP_ATTEMPTS) {
      return res.status(429).json({ message: 'Terlalu banyak percobaan salah. Minta kode OTP baru.' });
    }

    if (new Date(userRow.otp_expires_at) < new Date()) {
      return res.status(400).json({ message: 'Kode OTP sudah kedaluwarsa. Silakan minta kode baru.' });
    }

    const isMatch = await compareOtp(otp, userRow.otp_code);
    if (!isMatch) {
      await pool.query('UPDATE users SET otp_attempts = otp_attempts + 1 WHERE id = ?', [userRow.id]);
      return res.status(400).json({ message: 'Kode OTP salah.' });
    }

    await pool.query(
      'UPDATE users SET email_verified = 1, otp_code = NULL, otp_expires_at = NULL, otp_attempts = 0 WHERE id = ?',
      [userRow.id]
    );

    const user = { id: userRow.id, name: userRow.name, email: userRow.email, role: userRow.role };
    const token = signToken({ id: user.id, email: user.email, role: user.role });

    res.json({ message: 'Email berhasil diverifikasi.', user, token });
  } catch (err) {
    next(err);
  }
}

// POST /api/auth/resend-otp
// Body: { email }
async function resendOtp(req, res, next) {
  try {
    const { email } = req.body;
    if (!email) {
      return res.status(400).json({ message: 'Email wajib diisi.' });
    }

    const [rows] = await pool.query('SELECT * FROM users WHERE email = ?', [email]);
    if (rows.length === 0) {
      return res.status(404).json({ message: 'Akun tidak ditemukan.' });
    }

    const userRow = rows[0];
    if (userRow.email_verified) {
      return res.status(400).json({ message: 'Email ini sudah terverifikasi. Silakan login.' });
    }

    const otp = generateOtp();
    const otpHash = await hashOtp(otp);
    await pool.query(
      'UPDATE users SET otp_code = ?, otp_expires_at = ?, otp_attempts = 0 WHERE id = ?',
      [otpHash, getOtpExpiry(), userRow.id]
    );

    await sendOtpEmail(email, userRow.name, otp);

    res.json({ message: 'Kode OTP baru telah dikirim ke email kamu.' });
  } catch (err) {
    next(err);
  }
}

// POST /api/auth/login
async function login(req, res, next) {
  try {
    const { email, password } = req.body;
    if (!email || !password) {
      return res.status(400).json({ message: 'Email dan password wajib diisi.' });
    }

    const [rows] = await pool.query('SELECT * FROM users WHERE email = ?', [email]);
    if (rows.length === 0) {
      return res.status(401).json({ message: 'Email atau password salah.' });
    }

    const userRow = rows[0];

    if (userRow.provider === 'google' || !userRow.password_hash) {
      return res.status(400).json({ message: 'Akun ini terdaftar lewat Google. Silakan masuk dengan tombol "Masuk dengan Google".' });
    }

    const isMatch = await bcrypt.compare(password, userRow.password_hash);
    if (!isMatch) {
      return res.status(401).json({ message: 'Email atau password salah.' });
    }

    if (!userRow.email_verified) {
      return res.status(403).json({
        message: 'Email belum diverifikasi. Silakan cek kode OTP yang sudah dikirim ke emailmu.',
        needsVerification: true,
        email: userRow.email,
      });
    }

    const user = { id: userRow.id, name: userRow.name, email: userRow.email, role: userRow.role };
    const token = signToken({ id: user.id, email: user.email, role: user.role });

    res.json({ user, token });
  } catch (err) {
    next(err);
  }
}

// POST /api/auth/google
// Body: { credential }  -> ID token dari Google Identity Services (frontend)
// Karena Google sudah memverifikasi kepemilikan email, akun langsung aktif tanpa OTP.
async function googleAuth(req, res, next) {
  try {
    const { credential } = req.body;
    if (!credential) {
      return res.status(400).json({ message: 'Token Google tidak ditemukan.' });
    }

    let payload;
    try {
      payload = await verifyGoogleToken(credential);
    } catch (err) {
      return res.status(401).json({ message: 'Token Google tidak valid.' });
    }

    if (!payload.email_verified) {
      return res.status(400).json({ message: 'Email Google ini belum terverifikasi oleh Google.' });
    }

    const { sub: googleId, email, name, picture } = payload;

    const [rows] = await pool.query('SELECT * FROM users WHERE email = ? OR google_id = ?', [email, googleId]);

    let userRow;
    if (rows.length > 0) {
      userRow = rows[0];
      // Kalau sebelumnya daftar manual dengan email yang sama, tautkan akunnya ke Google
      // sekalian tandai terverifikasi (Google sudah memverifikasi email tsb).
      if (!userRow.google_id) {
        await pool.query(
          'UPDATE users SET google_id = ?, provider = ?, email_verified = 1 WHERE id = ?',
          [googleId, userRow.provider === 'local' ? userRow.provider : 'google', userRow.id]
        );
      }
    } else {
      const [result] = await pool.query(
        'INSERT INTO users (name, email, password_hash, role, provider, google_id, email_verified) VALUES (?, ?, NULL, ?, ?, ?, 1)',
        [name || email.split('@')[0], email, 'customer', 'google', googleId]
      );
      userRow = { id: result.insertId, name: name || email.split('@')[0], email, role: 'customer' };
    }

    const user = { id: userRow.id, name: userRow.name, email: userRow.email, role: userRow.role, picture };
    const token = signToken({ id: user.id, email: user.email, role: user.role });

    res.json({ user, token });
  } catch (err) {
    next(err);
  }
}

// GET /api/auth/me
async function me(req, res, next) {
  try {
    const [rows] = await pool.query(
      'SELECT id, name, email, role, created_at FROM users WHERE id = ?',
      [req.user.id]
    );
    if (rows.length === 0) {
      return res.status(404).json({ message: 'User tidak ditemukan.' });
    }
    res.json({ user: rows[0] });
  } catch (err) {
    next(err);
  }
}

module.exports = { register, login, me, verifyOtp, resendOtp, googleAuth, checkEmail };
