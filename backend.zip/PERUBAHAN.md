# Ringkasan Perubahan

## 1. Card bisa diklik → halaman detail
- `frontend/src/pages/Rooms.jsx`: gambar & judul room sekarang dibungkus `<Link to="/rooms/:id">`.
- `frontend/src/pages/RoomDetail.jsx` (baru): halaman detail dengan galeri foto (foto besar +
  thumbnail), lokasi, kapasitas, rating, deskripsi, dan form booking — mirip contoh Traveloka
  yang dikirim.
- `frontend/src/App.jsx`: route baru `/rooms/:id`.

## 2. Upload beberapa foto per room (backend + admin panel)
- Tabel baru `room_images` (lihat migration di bawah) — satu room bisa punya banyak foto.
- `backend/src/middleware/upload.js`: konfigurasi `multer`, simpan file di
  `backend/uploads/rooms/`, maks 5MB/file, maks 10 file sekali upload, hanya JPG/PNG/WEBP/GIF.
- `backend/server.js`: serve folder `uploads` secara statis di `http://localhost:5000/uploads/...`.
- Endpoint baru di `roomRoutes.js`:
  - `POST /api/rooms/:id/images` (admin, multipart, field `images`, bisa banyak file sekaligus)
  - `DELETE /api/rooms/:id/images/:imageId` (admin)
- `getRooms` / `getRoomById` sekarang mengembalikan field `images: [...]` untuk tiap room.
- `frontend/src/pages/Admin.jsx`: tombol "Kelola Foto" di tiap baris tabel → buka panel upload
  multi-file dengan preview thumbnail + tombol hapus per foto.

## 3. Field lokasi: negara + daerah (untuk pencarian)
- Kolom baru `country` di tabel `rooms` (field `location` yang sudah ada dipakai sebagai
  kota/daerah, mis. "Bandung, Sukajadi").
- Form Admin sekarang punya input terpisah **Lokasi/daerah** dan **Negara**.
- `GET /api/rooms` mendukung query filter `?country=...&location=...` untuk pencarian lokasi.
- Pencarian di halaman utama (`Rooms.jsx`) juga mencocokkan field `country`.

---

# Cara menjalankan

## Backend
```bash
cd backend
npm install          # menambahkan multer, dependency baru
mysql -u root -p booking_system < src/utils/migration_multi_image.sql
npm run dev
```

## Frontend
```bash
cd frontend
npm install
npm run dev
```

Folder `backend/uploads/` dibuat otomatis saat server pertama kali jalan (juga sudah
di-`.gitignore`, jangan lupa buat foldernya di server produksi atau biarkan multer yang
membuatnya otomatis).
